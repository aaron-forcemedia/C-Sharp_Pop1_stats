﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pop1_Stats_Collector
{
    class GameStats
    {
        public string WeeklyWinsTotal { get; set; } 
    }
}
