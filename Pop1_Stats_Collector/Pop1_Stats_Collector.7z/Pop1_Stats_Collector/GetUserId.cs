﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pop1_Stats_Collector
{
    class GetUserId
    {
        public string playFabId { get; set; }
        public string displayName { get; set; }

    }
}